/* 
 * File:   main.h
 * Author: ANAND S M
 *
 * Created on 26 March, 2024, 2:51 PM
 */

#ifndef MAIN_H
#define	MAIN_H


#define LED_ARRAY1              PORTD
#define LED_ARRAY1_DDR          TRISD

#define OFF                     0x00
#define SET                     1
#define RSET                    0

#endif	/* MAIN_H */

