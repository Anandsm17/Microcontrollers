/*
 * File:   main.c
 * Author: ANAND S M
 *
 * Date : 1 April, 2024, 1:12 PM
 * Description : Implement a static (non configurable) clock on SSD (Shown in the video) using internal timer.

Output Requirements:

As soon as the board is powered on or reset, the clock should start at 12.00.
The decimal point of the hours field (one?s place) should blink every 500 msecs (0.5 Hz)
The clock format should be 24 Hrs.

Inputs:
Timer
 */

#include <xc.h>
#include "ssd.h"
# include "timers.h"
#pragma config WDTE = OFF /*watch dog timer is enable */

/*variable declaration*/
int hour = 12, min = 0, flag = 0;
/*configuring display and ssd*/
void init_config(void)
{
	init_ssd();
    init_timer0();
    
    /* Enable all the Global Interrupts */
    GIE = 1;
}

void main(void)
{
    static unsigned char ssd[MAX_SSD_CNT];                                                     
    static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};       
	init_config();   
	unsigned int count = 0;
	unsigned int wait = 0;
	unsigned char key ;
    
    /* if flag bit is set, for every 1/2 sec dot point will blink
     * to get 2nd digit from hour
     * to get 1st digit from hour and blink dot for every 1/2 sec
     * to display second digit of minute
     * to display 1st digit of minute
     * in between every half second time will display but dot not get blink
     */
	while(1)
	{   
        if(flag)                        
        {
            ssd[0] = digit[hour/10];        
            ssd[1] = (digit[hour%10]| DOT);  
            ssd[2] = digit[min/10];     
            ssd[3] = digit[min%10];       
        }
        else                           
        {
            ssd[0] = digit[hour/10];
            ssd[1] = digit[hour%10];
            ssd[2] = digit[min/10];
            ssd[3] = digit[min%10];
        }
        display(ssd);
	}
}