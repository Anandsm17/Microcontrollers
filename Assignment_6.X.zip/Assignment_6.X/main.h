/* 
 * File:   main.h
 * Author: ANAND S
 *
 * Created on 1 April, 2024
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED1                RD0

#define LED_ARRAY          PORTD
#define LED_ARRAY_DDR      TRISD

#define ON                  1
#define OFF                 0

#endif	/* MAIN_H */


