/*
 * File:   main.c
 * Author: ANAND S M
 *
 * Date : 4 April, 2024
 * Description : Implement a 10 digit down counter with preset
 */

#include <xc.h>
#include <string.h>
#include "clcd.h"
#include "matrix_keypad.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)


static void init_config(void) {
    init_clcd();
     init_matrix_keypad();
}

void main(void) {
    
    init_config();   
    char msg[] = "0000000000";          
	unsigned long wait = 0;
	int i = 0 ,flag = 1, pos = 15;
	char temp ;
    unsigned char key;
     clcd_print("Down counter", LINE1(0));             
     clcd_print( "Count:", LINE2(0));
			
    while (1) {
           
        key = read_matrix_keypad(STATE);          
        /*set mode*/         
        if(key == 3)                      
        {           
            flag =!flag;                        
        }         
        /* if flag is set it is in edit mode*/          
        if(flag == 1)                              
        {               
            /*change the position*/               
            if(key == 2)                      
            {                  
                pos--;                  
                /* if position reach to 6th then restart with 15th position */                   
                if(pos < 6)                      
                {                      
                    pos = 15;                                                    
                }
              
            }             
            /*increase the current position value upto 9*/            
            else if(key == 1)                    
            {               
                msg[pos-6]++;                
                if(msg[pos-6] >= '9')                 
                {
                    msg[pos-6] = '0';                 
                }                  
                clcd_print(msg,LINE2(6));                                
            }                            
          
        }          
        else                                     
        {           			             
            /* to decrement  counter by 1 */			             
            msg[9] = msg[9]-1;
               
            if ( msg[9] == 47 )              
            {
                int index = 9;
                while( msg[index] == 47 && index >= 0 )                 
                {                       
                    msg[index] = '9';                      
                    index--;                                            
                    msg[index] = msg[index]-1;
                    
                }
                
            }
           
        }          
        clcd_print( msg, LINE2(6));       
    }
    return;
}
