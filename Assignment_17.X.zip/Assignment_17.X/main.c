/*
 * File:   main.c
 * Author: ANAND S M
 *
 * Date : 4 April, 2024
 * Description : Implement a 10 digit up counter on CLCD.

Output Requirements:

As soon as the board is powered up or reset, CLCD display the title (Up Counter) on the first line.  
On second line, 0000000000 (10 digit number) starts incrementing. 
 Increment happens at constant rate (You may have lesser delay as possible since it's a 10 digit counter). 
The counter stops after reaching count value of 9999999999 
 * 
 * 
 */


#include <xc.h>
#include "clcd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    init_clcd();
    
}

void main(void) {
    init_config();
    char str[]  = "0000000000";    
    static unsigned int i = 9, wait = 50000, j = 0;
    char inc = '0';
    clcd_print("UP COUNTER", LINE1(0));
    clcd_print("count:", LINE2(0));
    while (1) 
    {
        /*value automatically increased*/
        if(wait++ == 50000 )
        {
            wait = 0;
            clcd_print(str, LINE2(6));              
            str[9]++;
            for(int j = 9; j >= 0; j--)
            {
                if(str[j] == ':' )
                {
                    str[j-1]++;
                    str[j] = '0';
                }
            }                                   
        }
    }    
    return;
}
