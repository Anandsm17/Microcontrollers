/*
 * File:   main.c
 * Author: ANAND S M
 *
 * Date : 2 April, 2024, 12:05 PM
 * Description : Implement a scrolling number marquee on SSDs with scroll direction control on a key press

Output Requirement:

As soon as the board is powered on or reset, a static message (hardcoded) should start scrolling from right to left SSD.
The scroll should repeat indefinitely unless and until the direction change keys are pressed. 
The scroll frequency should be 0.5Hz (Approximately, Non Timer Based). 
On press of Right Direction Key, the scroll direction should change from left to right on the same instance. 
On press of Left Direction Key, the scroll direction should change from right to left on the same instance. 
On press of Stop / Start Key the scroll should be stopped on the same instance. 
On press of any key the scroll should start on the same instance.
 */


#include <xc.h>
#include "ssd.h"
#include "digital_keypad.h"
#pragma config WDTE = OFF        /* Watchdog Timer Enable bit (WDT disabled)*/

static void init_config(void) {
    /*initialization of keypad and ssd*/
    init_ssd();
    init_digital_keypad();
}

void main(void) 
{
    /*initialization of keypad and ssd values*/
    init_config();
    unsigned char ssd[MAX_SSD_CNT];
    unsigned char cur_key = SW1, key;
    unsigned int digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, UNDERSCORE, UNDERSCORE};
    unsigned int wait = 0, count = 0;
    while (1)
    {
        key = read_digital_keypad(STATE);
        
        if ( (key == SW1 || key == SW2 || key == SW3)  && cur_key != key )
		{
			cur_key = key ;		
		}
        if( wait++ == 200)
        {
            wait = 0;
            /*changing the direction on key pressed*/  
            /*Right to left scrolling*/
            if(cur_key == SW1)
            {           
                if(count++ >= 11)
                {
                    count = 0;
                }
            }
            /*Left to right scrolling*/
            else if(cur_key == SW2)
            {         
                if(count-- <= 0)
                {
                    count = 11;
                }
            
            }
        
        }
        /*set the values to ssd*/ 
        ssd[0] = digit[count];
        ssd[1] = digit[(count + 1)%12];
        ssd[2] = digit[(count + 2)%12];
        ssd[3] = digit[(count + 3)%12];

        display(ssd); 
        
    }
    return;
}
