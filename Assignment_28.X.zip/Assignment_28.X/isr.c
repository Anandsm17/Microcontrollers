
#include <xc.h>
#include "main.h"
#include "clcd.h"
unsigned long int period = 100,duty_cycle,loop_counter=0,wait;
void __interrupt() isr(void)
{        
    if (TMR0IF == 1)
    {
       if(loop_counter < duty_cycle)		                        
        {			               
            LED1 = ON;		            
        }		          
       else if(loop_counter > duty_cycle)	                
        {						                
            LED1 = OFF;		          
        }			       
        if(loop_counter++ == period)		            
        {		                 
            loop_counter = 0;		           
        } 
        TMR0IF = 0;
    }
    
}