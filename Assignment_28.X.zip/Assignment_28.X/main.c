/*
 * File:   main.c
 * Author: ANAND S M
 *
 * Date : 5 April, 2024, 10:51 AM
 * Description : Implement a LED dimmer application using PWM (Timer ISR Based). The current percentage of brightness  should displayed on the CLCD as Horizontal Bar.
 */


#include <xc.h>
#include "matrix_keypad.h"
#include "clcd.h"
#include "main.h"
#include "timers.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)

/*extern previous file variable visibility*/
extern unsigned  long int period;
extern unsigned  long int duty_cycle;
extern unsigned  long int loop_counter;
static void init_config(void)
{
    LED_ARRAY_1 = 0x00;    
    LED_ARRAY_DDR_1 = 0x00;  
    init_matrix_keypad();        
    init_clcd();        
    init_timer0();   
    
    /* Enable all the Global Interrupts */
    GIE = 1;

}
void main(void) {
    init_config();    
    unsigned char key;
    unsigned int wait;
	while(1)
	{             
        clcd_print("LED BRIGHTNESS",LINE1(0)); 
        /*read key from user*/
        key = read_matrix_keypad(LEVEL);         
        
           /*LED brightness increments*/
            if(key == 1)
            {
                if(duty_cycle != period)
                {
                   duty_cycle++;     
                }
                /*increment the bar */                 
                for(int i = 0; i <= ((duty_cycle * 10)/100); i++) 
                    clcd_putch(0xFF, LINE2(i));
            }
            /*LED brightness increments*/
            else if(key == 2)
            {
                if(duty_cycle != 0)
                {
                    duty_cycle--;
                }                                        
                /*decrement the bar */                                  
                for(int j = 10; j >= ((duty_cycle*10)/100); j--)                         
                    clcd_putch(0x00, LINE2(j)); 
            }
    
    }
    return;
}
