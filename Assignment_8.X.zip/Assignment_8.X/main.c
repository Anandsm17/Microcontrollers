/*
 * File:   main.c
 * Author: ANAND S M
 *
 * Date : 2 April, 2024, 10:35 AM
 * Description : Implement a LED dimmer application using PWM (Timer ISR Based). The brightness of the LED illumination should be based on the user input tuning the Knob of potentiometer.

Output Requirements:

On giving power supply to the board, read the value of pot. Based on that value, set the duty cycle. Again read the pot value
If it is different from previous value, update duty cycle accordingly
If it is same do nothing
Repeat the same on regular interval or continuously. 
Use timer to generate PWM
 */

#include <xc.h>
#include "main.h"
#include "timers.h"
#include "adc.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)
     
/*global variable declaration*/   
unsigned short adc_reg_val;     
void init_config(void) {
    LED_ARRAY1 = OFF;
    LED_ARRAY1_DDR = 0x00;    
  
    init_adc();      
    init_timer0();
    
    /* Enable all the Global Interrupts */
    GIE = 1;
}

void main(void) {   
    
    init_config();   
    while (1)
    {
        adc_reg_val = read_adc();//10 bits -> 0 to 1023          
    }
    return;
}

