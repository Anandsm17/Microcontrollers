/* 
 * File:   timers.h
 * Author: ANAND S
 *
 * Created on 1 April, 2024, 2:38 PM
 */

#ifndef TIMERS_H
#define	TIMERS_H

void init_timer0(void);
void init_timer2(void);
#endif	/* TIMERS_H */

