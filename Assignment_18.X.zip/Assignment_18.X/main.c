/*
 * File:   main.c
 * Author: ANAND S M
 *
 * Date : 4 April, 2024 
 * Description : Implement a 10 digit down counter on CLCD. 

Output Requirements:

As soon as the board is powered up or reset, CLCD display the title (Down Counter) on the first line.  
On second line, 9999999999 (10 digit number) starts decrementing. 
 Decrement happens at constant rate (You may have lesser delay as possible since it's a 10 digit counter).
The counter stops after reaching count value of 0000000000. 
 */

#include <xc.h>
#include <string.h>
#include "clcd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)


static void init_config(void) {
    init_clcd();
}

void main(void) {
    
    init_config();   
    char msg[] = "9999999999";
	unsigned long wait = 0;
	int i = 0 ;
	char temp ;

    while (1) {
            
		if ( wait++ == 50000 )
		{           
			wait = 0;
            /*printing on the display*/
            clcd_print("Down counter", LINE1(0));
            clcd_print( "Count:", LINE2(0));
			clcd_print( msg, LINE2(6));
            
			/* to decrement  counter by 1 */
			msg[9] = msg[9] - 1;
			if ( msg[9] == 47 )
			{
				int index = 9;
				do
				{
					msg[index] = '9';
					index--;
					msg[index] = msg[index]-1;
				}while( msg[index] == 47 && index >=0 );

			}
		
        }

       
    }
    return;
}
