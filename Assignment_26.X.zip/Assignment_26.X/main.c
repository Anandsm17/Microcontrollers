/*
 * File:   main.c
 * Author: ANAND S M
 *
 * Date : 3 April, 2024, 10:08 AM
 * Description : Implement a 4 digit key press counter with persistence using Internal EEPROM. 

Output Requirements:
- As soon as the board is powered up or reset, counter should display 0000 on SSDs.
- On every key press  counter value should increment by 1.
- On a  long key press (2 seconds), Count should  reset to zero.
- On pressing STORE switch, the current count should be  stored in internal EEPROM.
- On subsequent power ups or reset the counter should start from the previous stored value in the EEPROM.
Inputs:
DKS 1 as Count input .
DKS 1 Long press to reset the count .
DKS 2 Store Input.
 */



#include <xc.h>
#include "digital_keypad.h"
#include "ssd.h"
#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)
#define SW_WAIT     200 

unsigned char key;
unsigned char ssd[MAX_SSD_CNT];
unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE}; 
static unsigned  long int count = 0,flag = 1, wait = 0 , sw_count = 0; 
unsigned char eeprom_test(unsigned char key)
{
    while(1)
    {
        
        key = read_digital_keypad(LEVEL);
               
        if (key == SW2)
        {
            /*writing every digit in EEprom*/
            eeprom_write(0x03, (count % 10));
            eeprom_write(0x02, ((count % 100)/10));
            eeprom_write(0x01, ((count % 1000)/100));
            eeprom_write(0x00, (count / 1000));
        }          

        //count upto 9 on every key press(DKP3).
        //Once count exceeds 9 lets Roll back to 0.
        if (key == SW1)
        {                                                   
            if(flag)                                       
            {                                                         
                if (count++ == 9)
                {
                    count = 0;
                }
                flag = 0;                            
            }                             
            else               
            {                  
                sw_count--;                 
            }

        }                      
        else            
        {
            flag = 1;                   
        }       
       /*          
        *   If switch pressed for less than 2sec,           
        *  Calculating each digit of a 4 digit number.          
        *  Else reset count to 0 to display all 0 on SSD's.          
        *  Display on SSD using display function.           
        */                               
        if(sw_count > 0)          
        {                         
            if(wait++ == 25)               
            {   
                wait = 0;   
                ssd[3] = digit[(count % 10)];                                     
                ssd[2] = digit[(count % 100) / 10];                                   
                ssd[1] = digit[(count % 1000) / 100];                                    
                ssd[0] = digit[(count / 1000)];                                  

            }

        }                      
        else           
        {                               
            sw_count = SW_WAIT;                          
            count = 0;                     
        }                   
        if( count >= 9999 )           
        {
            while(1);           
        }       
        display(ssd);         
    }

}   

static void init_config(void) {
    init_digital_keypad();
    init_ssd(); 
}

void main(void) {

    init_config();                       
    while (1) 
    {      
        count = eeprom_test(key);

    }
    return;
}
