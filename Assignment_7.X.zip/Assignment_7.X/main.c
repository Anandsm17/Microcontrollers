/*
 * File:   main.c
 * Author: ANAND S M
 *
 * Date : 3 April, 2024, 10:27 AM
 * Description : Implement a LED dimmer application with bit banging PWM. The brightness of the LED illumination should be based on the user input tuning the Knob of potentiometer.

Output Requirement:

On giving power supply to the board, read the value of pot. Based on that value, set the duty cycle. Again read the pot value
If it is different from previous value, update duty cycle accordingly
If it is same do nothing
Repeat the same on regular interval or continuously. 
Use program cycles to generate PWM
 */


#include <xc.h>
#include "main.h"
#include "adc.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

void software_pwm(unsigned short adc_reg_val)
{
    /*variable declaration*/
    static unsigned long int period = 100, loop_counter = 0, wait = 0, duty_cycle = 50;    
    
    /*LED blinking was increasing when we are increasing the Nobe in pot meter*/
    /*Pot meter is 0to1023 until slowly brightness increasing*/    
    if(loop_counter < adc_reg_val)		
    {			
        LED1 = ON;		
    }		
    else if(loop_counter >= adc_reg_val && loop_counter < period )		
    {						
        LED1 = OFF;		
    }			
    if(loop_counter++ == period)		
    {		
        loop_counter = 0;		
    }	        
    
}	                    
           
static void init_config(void) {
    LED_ARRAY1 = OFF;
    LED_ARRAY1_DDR = 0x00;    
    init_adc();
}

void main(void) {
    unsigned short adc_reg_val; //0 to 1023
    
    init_config();

    while (1) {
        adc_reg_val = read_adc();//10 bits -> 0 to 1023       
        software_pwm(adc_reg_val/10);    
    }
    return;
}