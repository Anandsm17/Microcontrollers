/* 
 * File:   adc.h
 * Author: ANAND S M
 *
 * Created on 1 April, 2024, 2:26 PM
 */

#ifndef ADC_H
#define	ADC_H

void init_adc(void);
unsigned short read_adc(void);

#endif	/* ADC_H */


