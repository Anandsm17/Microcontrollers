/* 
 * File:   main.h
 * Author: ANAND S M
 *
 * Created on 1 April, 2024, 2:24 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED_ARRAY1_DDR              TRISD
#define LED_ARRAY1                  PORTD
#define LED1                        RD0

#define ON                          1
#define OFF                         0

#endif	/* MAIN_H */