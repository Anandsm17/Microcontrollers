/*
 * File:   main.c
 * Name: ANAND S M
 * Date : 1 April, 2024, 12:18 PM
 * Description : Implement a LED dimmer application using PWM (Timer ISR Based). The brightness of the LED illumination should be based on 
the user input using the switches.
 * 
 * Output Requirement:

As soon as the board is powered on or reset, The LED should glow with 50% Duty Cycle (i.e the glow, half of its maximum intensity).
The Increment Brightness Input should increase the Duty Cycle upto 100% (Total ON)
The Decrement Brightness Input should decrease the Duty Cycle to 0% (Total OFF)
Inputs:

- DKS1 as Increase Brightness Input, Level Triggered
- DKS2 as Decrease Brightness Input, Level Triggered
- Program Cycles as Period

 *  
 * 
 */

#include <xc.h>
#include "main.h"
#include "timers.h"
#include "digital_keypad.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)

/*extern previous file variable visibility*/
extern unsigned  long int period;
extern unsigned  long int duty_cycle;
extern unsigned  long int loop_counter;
static void init_config(void)
{
	LED_ARRAY = 0x00;    
	LED_ARRAY_DDR = 0x00;
    
    init_digital_keypad(); 
    init_timer0();   
    
    /* Enable all the Global Interrupts */
    GIE = 1;

}
void main(void) {
    init_config();
    unsigned char key;
    unsigned int wait;
  
	while(1)
	{   
        /*non blocking delay*/
        if(wait-- == 0)
        {
            wait = 2500;
            /*read key from user*/
            key = read_digital_keypad(LEVEL);
            /*LED brightness increments*/
            if(key == SW1)
            {
                if(duty_cycle != period)
                {
                   duty_cycle++;     
                }
            }
            /*LED brightness increments*/
            else if(key == SW2)
            {
                if(duty_cycle != 0)
                {
                    duty_cycle--;
                }
            }
        }
        
    }
    return;
}
