/*
 * File:   main.c
 * Author: ANAND S M
 *
 * Date : 2 April, 2024
 * Description : Implement a 4 digit key press counter.

Output Requirement:

Implement a 4 digit key press counter


On every key press counter value should increment by 1.

On a long key press (2 seconds), count should reset to zero.

Inputs:

DKS1 (Digital Keypad Switch 1) as Count Input 
DKS1 long press (2 secs) to reset the count 
 */


#include <xc.h>
#include "ssd.h"
#include "digital_keypad.h"

/* Watchdog Timer Enable bit (WDT disabled) */
#pragma config WDTE = OFF

/* Function: init_config()
 * Description: This function is used to setup initial peripheral
 *              configuration, like setting port directions, initializing port values
 */
static void init_config(void)
{
    init_ssd(); /* initializing ssd */
    init_digital_keypad(); /* initializing digital keypad */
}

void main(void)
{
    /* initialization */
    unsigned char ssd[MAX_SSD_CNT];
    unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
    /*                          0    1    2      3     4     5    6      7      8     9 */
    unsigned int count = 0;
    unsigned int wait = 0;
    unsigned char key_inc;
    unsigned char key_lp;

    init_config(); /* function call */

    while (1) /*super loop */
    {
        key_inc = read_digital_keypad(STATE); /* key for state change */
        key_lp = read_digital_keypad(LEVEL); /* key for level trigger */

        if (key_inc == SW1) /* if state change, increment the count */
        {
            count++;

            if (count > 9999) /* if count value reaches 9999, reset to 0 */
            {
                count = 0;
            }
        }

        if (key_lp == SW1) /* if level triggered, increment the wait value */
        {
            wait++;
        }
        else
        {
            wait = 0; /* else reset wait to 0 */
        }

        if (wait == 150) /* when wait value reach 150 (which gives 2sec delay) */
        {
            count = 0; /* reset the count to 0 */
        }

        /* displaying */
        ssd[0] = digit[(count / 1000)];
        ssd[1] = digit[((count % 1000) / 100)];
        ssd[2] = digit[((count % 100) / 10)];
        ssd[3] = digit[(count % 10)];

        display(ssd);
    }

    return;
}